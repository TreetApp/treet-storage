const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Pg1R5igY.js","assets/index-BmuFdEnv.js","assets/index-vtLXtwTB.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BmuFdEnv.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-Pg1R5igY.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
