const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CTq5fRcw.js","assets/index-Coxf5Cx9.js","assets/index-CBCibfW0.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Coxf5Cx9.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-CTq5fRcw.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
