const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BpnZi2hD.js","assets/index-f7eKXP-E.js","assets/index-wVZEwuuE.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-f7eKXP-E.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-BpnZi2hD.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
