import{W as n}from"./index-f7eKXP-E.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
