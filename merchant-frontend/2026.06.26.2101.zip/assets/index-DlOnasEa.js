const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BtylBFMe.js","assets/index-PPMrzgMN.js","assets/index-_akIHb5i.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-PPMrzgMN.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-BtylBFMe.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
