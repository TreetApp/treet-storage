const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DE8MBE66.js","./index-CkiiokF8.js","./index-w5rDQTi-.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CkiiokF8.js";const _=r("SplashScreen",{web:()=>t(()=>import("./web-DE8MBE66.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.SplashScreenWeb)});export{_ as SplashScreen};
