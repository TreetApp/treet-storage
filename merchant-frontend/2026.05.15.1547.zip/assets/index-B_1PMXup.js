const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BMW2cIfQ.js","assets/index-CCx-wWqq.js","assets/index-Cf2259yJ.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CCx-wWqq.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-BMW2cIfQ.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
