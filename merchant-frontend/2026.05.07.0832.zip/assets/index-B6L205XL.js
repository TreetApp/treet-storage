const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Bx72eosW.js","assets/index-DR_J9b7K.js","assets/index-BWUbTg6t.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DR_J9b7K.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-Bx72eosW.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
