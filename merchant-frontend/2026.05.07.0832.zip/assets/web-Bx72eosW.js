import{W as n}from"./index-DR_J9b7K.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
