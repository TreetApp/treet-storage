const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DwRl5cra.js","assets/index-DAOlyl9R.js","assets/index-BflRsc_i.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DAOlyl9R.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-DwRl5cra.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
