import{W as n}from"./index-DAOlyl9R.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
