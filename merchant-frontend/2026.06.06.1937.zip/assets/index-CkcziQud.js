const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DFYi0aqs.js","assets/index-CwvgOcCh.js","assets/index-CQ68Zb32.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CwvgOcCh.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-DFYi0aqs.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
