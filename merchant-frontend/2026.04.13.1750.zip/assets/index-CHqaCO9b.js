const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Ca6ZeIxZ.js","./index-Cf7gU0qs.js","./index-DItQiIBL.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Cf7gU0qs.js";const _=r("SplashScreen",{web:()=>t(()=>import("./web-Ca6ZeIxZ.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.SplashScreenWeb)});export{_ as SplashScreen};
