import{W as n}from"./index-C52uGnE8.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
