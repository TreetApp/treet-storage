const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Y46D8JCU.js","assets/index-DQqjLc-3.js","assets/index-D26Shfng.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DQqjLc-3.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-Y46D8JCU.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
