const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BDuS210a.js","assets/index-LJxE3aZG.js","assets/index-Cf2259yJ.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-LJxE3aZG.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-BDuS210a.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
