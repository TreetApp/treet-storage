const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CVWR_Gv2.js","assets/index-B1R9mTgD.js","assets/index-BA6YBG7Q.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-B1R9mTgD.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-CVWR_Gv2.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
