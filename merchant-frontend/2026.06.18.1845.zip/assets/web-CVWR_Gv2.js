import{W as n}from"./index-B1R9mTgD.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
