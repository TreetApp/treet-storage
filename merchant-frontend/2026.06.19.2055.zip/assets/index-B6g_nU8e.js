const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-h6k_BwJK.js","assets/index-CRISHBK_.js","assets/index-B5L0qy8p.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CRISHBK_.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-h6k_BwJK.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
