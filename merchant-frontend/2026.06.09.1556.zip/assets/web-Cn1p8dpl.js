import{W as n}from"./index-Dk_09nSY.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
