const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Cn1p8dpl.js","assets/index-Dk_09nSY.js","assets/index-vtLXtwTB.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Dk_09nSY.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-Cn1p8dpl.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
