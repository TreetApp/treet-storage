const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CRDkex8H.js","assets/index-BbkLzrM1.js","assets/index-DmLz1zSz.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-BbkLzrM1.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-CRDkex8H.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
