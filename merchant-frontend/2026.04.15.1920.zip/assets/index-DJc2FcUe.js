const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C3WX5s41.js","./index-ChJJFeeC.js","./index-DItQiIBL.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-ChJJFeeC.js";const _=r("SplashScreen",{web:()=>t(()=>import("./web-C3WX5s41.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.SplashScreenWeb)});export{_ as SplashScreen};
